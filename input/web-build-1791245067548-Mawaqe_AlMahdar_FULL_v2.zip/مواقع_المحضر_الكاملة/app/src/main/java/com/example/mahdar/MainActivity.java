package com.example.mahdar;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String PASSWORD="farida1971";
    final int BLUE=Color.rgb(21,101,192), GRAY=Color.rgb(245,245,245);
    Db db; LinearLayout root,listBox; EditText search; double pendingLat=Double.NaN,pendingLon=Double.NaN;

    @Override public void onCreate(Bundle b){super.onCreate(b); db=new Db(this); showLogin();}
    TextView title(String s){TextView t=new TextView(this); t.setText(s);t.setTextSize(22);t.setTextColor(Color.WHITE);t.setGravity(Gravity.CENTER);t.setPadding(8,18,8,18);t.setBackgroundColor(BLUE);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setPadding(18,12,18,12);return e;}
    void base(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(GRAY);setContentView(root);}
    void showLogin(){base();root.addView(title("مواقع المحضر")); Space sp=new Space(this);root.addView(sp,new LinearLayout.LayoutParams(1,70));
      TextView w=new TextView(this);w.setText("تسجيل الدخول");w.setTextSize(20);w.setGravity(Gravity.CENTER);root.addView(w);
      EditText p=edit("كلمة السر");p.setInputType(0x81);root.addView(p,new LinearLayout.LayoutParams(-1,-2));
      Button go=btn("دخول");root.addView(go); TextView info=new TextView(this);info.setGravity(Gravity.CENTER);root.addView(info);
      go.setOnClickListener(v->{if(PASSWORD.equals(p.getText().toString())) showHome();else info.setText("كلمة السر غير صحيحة");}); }
    void showHome(){base();root.addView(title("مواقع المحضر"));
      LinearLayout top=new LinearLayout(this);top.setPadding(8,8,8,0);top.setOrientation(LinearLayout.HORIZONTAL);
      search=edit("ابحث بالاسم أو اللقب...");top.addView(search,new LinearLayout.LayoutParams(0,-2,1));Button add=btn("+ إضافة");top.addView(add,new LinearLayout.LayoutParams(-2,-2));root.addView(top);
      search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh(s.toString());}public void afterTextChanged(android.text.Editable e){}});
      add.setOnClickListener(v->showForm(-1,null));
      ScrollView sv=new ScrollView(this);listBox=new LinearLayout(this);listBox.setOrientation(LinearLayout.VERTICAL);listBox.setPadding(8,8,8,30);sv.addView(listBox);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));refresh(""); }
    void refresh(String q){if(listBox==null)return;listBox.removeAllViews();Cursor c=db.search(q);boolean any=false;while(c.moveToNext()){any=true;final int id=c.getInt(0);String name=c.getString(1)+" "+c.getString(2);String loc=c.getString(6);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(16,12,16,12);card.setBackgroundColor(Color.WHITE);TextView n=new TextView(this);n.setText(name);n.setTextSize(19);n.setTextColor(Color.DKGRAY);card.addView(n);TextView d=new TextView(this);d.setText("الأب: "+c.getString(3)+"   |   الميلاد: "+c.getString(5)+(loc.length()>0?"\nالموقع: "+loc:""));card.addView(d);LinearLayout actions=new LinearLayout(this);Button open=btn("عرض");Button edit=btn("تعديل");Button del=btn("حذف");actions.addView(open);actions.addView(edit);actions.addView(del);card.addView(actions);listBox.addView(card,new LinearLayout.LayoutParams(-1,-2));Space s=new Space(this);listBox.addView(s,new LinearLayout.LayoutParams(1,8));
        double lat=c.getDouble(7),lon=c.getDouble(8);String note=c.getString(9),mother=c.getString(4),father=c.getString(3),dob=c.getString(5),address=c.getString(6),fn=c.getString(1),ln=c.getString(2);Person p=new Person(id,fn,ln,father,mother,dob,address,note,lat,lon);
        open.setOnClickListener(v->showDetails(p));edit.setOnClickListener(v->showForm(id,p));del.setOnClickListener(v->confirmDelete(id,name)); }
      c.close();if(!any){TextView e=new TextView(this);e.setText("لا توجد سجلات");e.setGravity(Gravity.CENTER);e.setPadding(10,40,10,40);listBox.addView(e);}}
    void showDetails(Person p){new AlertDialog.Builder(this).setTitle(p.fn+" "+p.ln).setMessage("اسم الأب: "+p.father+"\nاسم الأم: "+p.mother+"\nتاريخ الميلاد: "+p.dob+"\nالموقع: "+p.address+"\nملاحظة: "+p.note+"\nالإحداثيات: "+(Double.isNaN(p.lat)?"غير محفوظ":p.lat+", "+p.lon)).setPositiveButton("الملاحة",(d,w)->navigate(p)).setNegativeButton("إغلاق",null).show();}
    void showForm(int id,Person old){base();root.addView(title(id<0?"إضافة شخص":"تعديل بيانات شخص"));ScrollView sv=new ScrollView(this);LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(16,10,16,30);sv.addView(f);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
      EditText fn=edit("الاسم");EditText ln=edit("اللقب");EditText fa=edit("اسم الأب");EditText mo=edit("اسم الأم");EditText dob=edit("تاريخ الميلاد");EditText addr=edit("الموقع / العنوان");EditText note=edit("ملاحظة");
      if(old!=null){fn.setText(old.fn);ln.setText(old.ln);fa.setText(old.father);mo.setText(old.mother);dob.setText(old.dob);addr.setText(old.address);note.setText(old.note);pendingLat=old.lat;pendingLon=old.lon;}else{pendingLat=Double.NaN;pendingLon=Double.NaN;}
      for(EditText e:new EditText[]{fn,ln,fa,mo,dob,addr,note})f.addView(e,new LinearLayout.LayoutParams(-1,-2));Button gps=btn("📍 حفظ موقعي الحالي");f.addView(gps);TextView coord=new TextView(this);coord.setText(Double.isNaN(pendingLat)?"لم يتم تحديد موقع":"الموقع: "+pendingLat+", "+pendingLon);f.addView(coord);gps.setOnClickListener(v->getLocation(coord));
      Button save=btn("💾 حفظ");Button back=btn("رجوع");f.addView(save);f.addView(back);back.setOnClickListener(v->showHome());save.setOnClickListener(v->{if(fn.getText().toString().trim().isEmpty()&&ln.getText().toString().trim().isEmpty()){Toast.makeText(this,"اكتب الاسم أو اللقب",Toast.LENGTH_SHORT).show();return;}if(id<0)db.insert(fn.getText().toString(),ln.getText().toString(),fa.getText().toString(),mo.getText().toString(),dob.getText().toString(),addr.getText().toString(),note.getText().toString(),pendingLat,pendingLon);else db.update(id,fn.getText().toString(),ln.getText().toString(),fa.getText().toString(),mo.getText().toString(),dob.getText().toString(),addr.getText().toString(),note.getText().toString(),pendingLat,pendingLon);showHome();});}
    void getLocation(TextView coord){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},5);return;}LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);Location best=null;for(String p:new String[]{LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER})try{Location l=lm.getLastKnownLocation(p);if(l!=null&&(best==null||l.getTime()>best.getTime()))best=l;}catch(Exception ignored){}if(best!=null){pendingLat=best.getLatitude();pendingLon=best.getLongitude();coord.setText("الموقع: "+pendingLat+", "+pendingLon);}else{Toast.makeText(this,"فعّل GPS وحاول مرة أخرى",Toast.LENGTH_LONG).show();startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));}}
    void navigate(Person p){if(Double.isNaN(p.lat)||Double.isNaN(p.lon)){Toast.makeText(this,"لا توجد إحداثيات محفوظة لهذا الشخص",Toast.LENGTH_SHORT).show();return;}Uri u=Uri.parse("google.navigation:q="+p.lat+","+p.lon);try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/dir/?api=1&destination="+p.lat+","+p.lon)));}}
    void confirmDelete(int id,String name){new AlertDialog.Builder(this).setTitle("حذف السجل").setMessage("هل تريد حذف "+name+"؟").setPositiveButton("حذف",(d,w)->{db.delete(id);refresh(search==null?"":search.getText().toString());}).setNegativeButton("إلغاء",null).show();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==5&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)Toast.makeText(this,"تم السماح بالموقع، اضغط زر الموقع مرة أخرى",Toast.LENGTH_SHORT).show();}
    static class Person{int id;String fn,ln,father,mother,dob,address,note;double lat,lon;Person(int i,String a,String b,String c,String d,String e,String f,String g,double h,double j){id=i;fn=a;ln=b;father=c;mother=d;dob=e;address=f;note=g;lat=h;lon=j;}}
    static class Db extends SQLiteOpenHelper{Db(Context c){super(c,"mahdar.db",null,2);}public void onCreate(SQLiteDatabase x){x.execSQL("CREATE TABLE people(id INTEGER PRIMARY KEY AUTOINCREMENT,fn TEXT,ln TEXT,father TEXT,mother TEXT,dob TEXT,address TEXT,note TEXT,lat REAL,lon REAL)");}public void onUpgrade(SQLiteDatabase x,int a,int b){if(a<2){try{x.execSQL("ALTER TABLE people ADD COLUMN note TEXT");}catch(Exception ignored){}}}void insert(String a,String b,String c,String d,String e,String f,String g,double h,double i){ContentValues v=cv(a,b,c,d,e,f,g,h,i);getWritableDatabase().insert("people",null,v);}void update(int id,String a,String b,String c,String d,String e,String f,String g,double h,double i){getWritableDatabase().update("people",cv(a,b,c,d,e,f,g,h,i),"id=?",new String[]{""+id});}ContentValues cv(String a,String b,String c,String d,String e,String f,String g,double h,double i){ContentValues v=new ContentValues();v.put("fn",a);v.put("ln",b);v.put("father",c);v.put("mother",d);v.put("dob",e);v.put("address",f);v.put("note",g);if(Double.isNaN(h))v.putNull("lat");else v.put("lat",h);if(Double.isNaN(i))v.putNull("lon");else v.put("lon",i);return v;}Cursor search(String q){String s="%"+q+"%";return getReadableDatabase().query("people",new String[]{"id","fn","ln","father","mother","dob","address","lat","lon","note"},"fn LIKE ? OR ln LIKE ?",new String[]{s,s},null,null,"ln,fn");}void delete(int id){getWritableDatabase().delete("people","id=?",new String[]{""+id});}}
}
